package program1;

public class Lecturer extends ResearchEmployee {

	public Lecturer(String field_of_study) {
		super(field_of_study);
	}

	public void teach() {
		// TODO - implement Lecturer.teach
		throw new UnsupportedOperationException();
	}

	public String createATrainingProgram() {
		// TODO - implement Lecturer.createATrainingProgram
		throw new UnsupportedOperationException();
	}

	public int giveMarksToStudents() {
		// TODO - implement Lecturer.giveMarksToStudents
		throw new UnsupportedOperationException();
	}

}
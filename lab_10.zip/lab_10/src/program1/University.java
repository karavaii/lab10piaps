package program1;

public class University {

	public String name;
	public String address;
	public char phone;

	public University(String name, String address, char phone) {
		this.address = address;
		this.phone = phone;
		this.name = name;
	}

	public void toProvideEducation() {
		// TODO - implement University.toProvideEducation
		throw new UnsupportedOperationException();
	}

	public void addEmployee() {
		// TODO - implement University.addEmployee
		throw new UnsupportedOperationException();
	}

}
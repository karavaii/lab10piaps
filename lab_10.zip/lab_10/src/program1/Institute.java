package program1;

public class Institute {

	public String name;
	public String address;

	public void conductingResearchWork() {
		// TODO - implement Institute.conductingResearchWork
		throw new UnsupportedOperationException();
	}

	public void studentSupervision() {
		// TODO - implement Institute.studentSupervision
		throw new UnsupportedOperationException();
	}

}
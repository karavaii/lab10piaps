package program1;

public class Student {

	public String full_name;

	public Student(String full_name) {
		this.full_name = full_name;
	}

	public void study() {
		// TODO - implement Student.study
		throw new UnsupportedOperationException();
	}

}
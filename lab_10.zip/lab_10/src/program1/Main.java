package program1;

public class Main {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		//задаю университет в котором всё и происходит
		University university = new University("VSU", "University Square 1", (char) 777);
		//научник
		ResearchEmployee researcher = new ResearchEmployee("Mathematical analysis");
		//и декан всея университета
		Dean dean = new Dean("Krylovetsky", 1024);
		//и проект в котором будет задействован научник
		Project project = new Project();

		System.out.print("In the " + university.name + " university, with " + dean.name + " as dean, ");
		System.out.print("average researcher's field of study is " + researcher.field_of_study + ".\n");
		System.out.println("In case you want to know quantity of hours, which the project will take:");
		System.out.println("Duration of project is " + project.getProjectCompleteANumberOfHours() + " hours.");

	}

}
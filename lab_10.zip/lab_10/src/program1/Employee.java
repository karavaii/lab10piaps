package program1;

public class Employee {

	public int SSnumber;
	public String name;
	public String email;
	public int number_employee;

	public void performanceOfOfficialDuties() {
		// TODO - implement Employee.performanceOfOfficialDuties
		throw new UnsupportedOperationException();
	}

	public void getSalary() {
		// TODO - implement Employee.getSalary
		throw new UnsupportedOperationException();
	}

}
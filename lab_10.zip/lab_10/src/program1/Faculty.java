package program1;

public class Faculty {

	public String name;

	public void acceptNewStudents() {
		// TODO - implement Faculty.acceptNewStudents
		throw new UnsupportedOperationException();
	}

	public void removeBadStudents() {
		// TODO - implement Faculty.removeBadStudents
		throw new UnsupportedOperationException();
	}

	public String viewStudentsSchedule() {
		// TODO - implement Faculty.viewStudentsSchedule
		throw new UnsupportedOperationException();
	}

	public String viewLecturersSchedule() {
		// TODO - implement Faculty.viewLecturersSchedule
		throw new UnsupportedOperationException();
	}

}
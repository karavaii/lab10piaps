package program1;

public class Course {

	public String name;
	public int id;
	public int weekly_duration;

	public void addToTheEducationalPlatform() {
		// TODO - implement Course.addToTheEducationalPlatform
		throw new UnsupportedOperationException();
	}

}
package program1;

public class Dean extends Employee {

	public int SSnumber;
	public String name;
	public String email;
	public int number_employee;

	public Dean(String name, int number_employee) {
		this.name = name;
		this.number_employee = number_employee;
	}

	public void managementOfTheFaculty() {
		// TODO - implement Dean.managementOfTheFaculty
		throw new UnsupportedOperationException();
	}

	public String viewEducationPlans() {
		// TODO - implement Dean.viewEducationPlans
		throw new UnsupportedOperationException();
	}

}
package program1;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Project {

	public String name;
	public java.util.Date start;
	public java.util.Date end;
	public int hours;

	public int getProjectCompleteANumberOfHours() {
		Scanner scan = new Scanner(System.in);

		System.out.println("Project start date (YYYY-MM-DD): ");
		String startProjectInput = scan.nextLine();
		LocalDate start = LocalDate.parse(startProjectInput);

		System.out.println("Project end day (YYYY-MM-DD): ");
		String endProjectInput = scan.nextLine();
		LocalDate end = LocalDate.parse(endProjectInput);

		long projectDays = ChronoUnit.DAYS.between(start, end);
		return (int) projectDays*24;
	}

}
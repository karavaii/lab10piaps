package program1;

public class ResearchEmployee extends Employee {

	public String field_of_study;

	public ResearchEmployee(String field_of_study) {
		this.field_of_study = field_of_study;
	}

	public String doResearchPaperWork() {
		// TODO - implement ResearchEmployee.doResearchPaperWork
		throw new UnsupportedOperationException();
	}

	public void superviseTheResearchFieldOfStudents() {
		// TODO - implement ResearchEmployee.superviseTheResearchFieldOfStudents
		throw new UnsupportedOperationException();
	}

	public String getField_of_study() {
		return field_of_study;
	}
}